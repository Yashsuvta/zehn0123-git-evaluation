
{
    "name": "TIS CRM",
    "version": "17.0",
    'author': "Techinfini Solutions Pvt. Ltd.",
    'summary': "This module enable user to create lead directly from the contact form of website.",
    'description': "This module enable user to create lead directly from the contact form of website.",
    "website": "",
    "depends":['base','contacts','crm'],
    "data": [
        'views/res_user.xml',
        'data/security.xml',
        'views/menus.xml',
        'security/ir.model.access.csv',
        
    ],
    "assets": {}, 
    'installable': True,
    'application': False,
    'auto_install': False,  
    'images': [],
}
