import logging
import json
from odoo import http, _
from odoo.http import request

from odoo.exceptions import UserError


_logger = logging.getLogger(__name__)


class leads(http.Controller):

    @http.route("/leads/sync/create", methods=["POST"], type="json", auth="public")
    def create_data(self, **kwargs):
            try:
                raw_data = request.httprequest.data

                # Decode and parse the JSON data
                data = json.loads(raw_data.decode('utf-8'))
                _logger.info("Received data: %s", data)

                if not data:
                    raise UserError(_("Data is not available!!"))

                if not data.get("name", None):
                    raise UserError("Invalid Name")

                customer = None
                if data.get("email"):
                    customer = (
                        request.env["res.partner"]
                        .sudo()
                        .search([("email", "=", data.get("email", None))], limit=1)
                    )
                    if not customer:
                        customer = (
                            request.env["res.partner"]
                            .sudo()
                            .create(
                                {
                                    "name": (
                                        data.get("name")
                                        if data.get("name")
                                        else data.get("email", " ").split("@")[0]
                                    ),
                                    "phone": data.get("phone", None),
                                    "mobile": data.get("phone", None),
                                    "email": data.get("email", None),
                                }
                            )
                        )
                
                description = data.get("description") if data.get("description") else ''
                
                # Handle tags
                tag_ids = []
                if data.get("tags"):
                    tags = data.get("tags")
                    tag_records = request.env["crm.tag"].sudo().search([("name", "in", tags)])
                    existing_tag_names = tag_records.mapped("name")
                    # Create any tags that don't already exist
                    for tag_name in tags:
                        if tag_name not in existing_tag_names:
                            tag_record = request.env["crm.tag"].sudo().create({"name": tag_name})
                            tag_ids.append(tag_record.id)
                        else:
                            tag_ids.append(tag_records.filtered(lambda r: r.name == tag_name).id)

                vals = {
                    "name": data.get("name", None),
                    "email_from": data.get("email", None),
                    "phone": data.get("phone", None),
                    "partner_id": customer.id if customer else None,
                    "partner_name": data.get("company", None),
                    "type": "lead",
                    'description': description,
                    "tag_ids": [(6, 0, tag_ids)],
                }
                new_data = request.env["crm.lead"].sudo().create(vals)

                _logger.info("API Completed Successfully [%s]!!", new_data.id)
                return {"lead_id": new_data.id}

            except Exception as e:
                raise UserError(_("Operation Failed [%s]: ", e))