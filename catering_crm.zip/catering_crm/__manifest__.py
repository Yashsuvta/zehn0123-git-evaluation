
{
    "name": "Catering CRM",
    "version": "17.0.1.0.1",
    'author': "Techinfini Solutions Pvt. Ltd.",
    'summary': "This module enable user to create lead directly from the contact form of website.",
    'description': "This module enable user to create lead directly from the contact form of website.",
    "website": "",
    "depends":['base','contacts', 'crm', 'sale'],
    "data": [
        'views/res_user.xml',
        'data/security.xml',
        'data/sales_team.xml',
        'views/res_config_settings.xml',
        'views/menus.xml',
        'views/sale_order.xml',      
    ],
    "assets": {}, 
    'installable': True,
    'application': True,
    'auto_install': False,  
    'images': [],
}
