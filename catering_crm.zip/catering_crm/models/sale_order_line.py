from odoo import models, fields, api

class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.onchange('product_id')
    def _apply_discount_based_on_customer(self):
        """Apply discount based on customer type when a product is added."""
        for line in self:
            discount_percentage_individual = float(
                self.env['ir.config_parameter'].sudo().get_param('discount_percentage_individual')
            )
            discount_percentage_company = float(
                self.env['ir.config_parameter'].sudo().get_param('discount_percentage_company')
            )

            if line.order_id.partner_id.is_company:
                line.discount = discount_percentage_company if discount_percentage_company else 0
            else:
                line.discount = discount_percentage_individual if discount_percentage_individual else 0


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.onchange('partner_id')
    def _apply_discount_based_on_customer(self):
        """Apply discount based on customer type when the partner changes."""
        discount_percentage_individual = float(
            self.env['ir.config_parameter'].sudo().get_param('discount_percentage_individual')
        )
        discount_percentage_company = float(
            self.env['ir.config_parameter'].sudo().get_param('discount_percentage_company',)
        )

        for line in self.order_line:
            if self.partner_id.is_company:
                line.discount = discount_percentage_company if discount_percentage_company else 0
            else:
                line.discount = discount_percentage_individual if discount_percentage_individual else 0

    @api.model
    def create(self, vals):
        order_date = vals.get('date_order', fields.Datetime.now())
        if isinstance(order_date, str):
            order_date = fields.Datetime.from_string(order_date)
        
        if order_date.month in [7, 12]:
            if 'order_line' in vals:
                for line in vals['order_line']:
                    if isinstance(line, dict):
                        product_id = line.get('product_id')
                        product = self.env['product.product'].browse(product_id)
                        if product:
                            original_price = product.lst_price
                            new_price = original_price * 1.10
                            line['price_unit'] = new_price
                    elif isinstance(line, (list, tuple)) and len(line) > 2:
                        line_data = line[2]
                        product_id = line_data.get('product_id')
                        product = self.env['product.product'].browse(product_id)
                        if product:
                            original_price = product.lst_price
                            new_price = original_price * 1.10 
                            line_data['price_unit'] = new_price

        return super(SaleOrder, self).create(vals)
