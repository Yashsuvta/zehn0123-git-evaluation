from odoo import models, fields, api
from datetime import datetime

class ProductPriceUpdate(models.Model):
    _inherit = 'product.template'

    original_price = fields.Float(string='Original Price', compute='_compute_original_price', store=True)

    @api.depends('list_price')
    def _compute_original_price(self):
        for product in self:
            if not product.original_price:
                product.original_price = product.list_price

    @api.model
    def update_product_prices(self): 
        today = datetime.today()
        if today.month in [7, 12]:
            products = self.search([])
            for product in products:
                if not product.original_price:
                    product.original_price = product.list_price
                new_price = product.list_price * 1.10
                product.write({'list_price': new_price})
        else:
            products = self.search([])
            for product in products:
                if product.original_price:
                    product.write({'list_price': product.original_price})
