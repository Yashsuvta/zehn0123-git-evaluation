from odoo import models, fields, api

class AccountMove(models.Model):
    _inherit = 'account.move'

    invoice_name = fields.Char(string="Number")

    @api.model
    def create(self, vals):
        # Assign custom sequence only if it's an outgoing invoice and no name is set
        if vals.get('move_type') == 'out_invoice':
            if not vals.get('invoice_name'):
                # Use get method with a default empty string
                sequence = self.env['ir.sequence'].next_by_code('account.move.invoice')
                vals['invoice_name'] = sequence
                print("Assigned custom sequence on creation:", sequence)
            else:
                vals['invoice_name'] = ''
        # Create the invoice with the updated values
        invoice = super(AccountMove, self).create(vals)
        return invoice

