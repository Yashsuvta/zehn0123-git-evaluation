from odoo import models, fields

class ResUsers(models.Model):
    _inherit = 'res.users'

    manager_id = fields.Many2one('res.users', string='Manager', help='The manager of this user.')
