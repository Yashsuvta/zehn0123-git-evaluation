from odoo import fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    discount_percentage_individual = fields.Integer(
        string='Individual Discount(%)',
        config_parameter='discount_percentage_individual'
    )
    discount_percentage_company = fields.Integer(
        string='Company Discount(%)',
        config_parameter='discount_percentage_company'
    )
